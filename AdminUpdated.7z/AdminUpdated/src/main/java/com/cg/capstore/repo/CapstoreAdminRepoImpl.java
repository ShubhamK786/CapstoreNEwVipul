package com.cg.capstore.repo;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Product;


@Repository
@Transactional
public class CapstoreAdminRepoImpl implements ICapstoreAdminRepo{
	@PersistenceContext
	EntityManager entityManager;
    
	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	public String addProduct(Product product)
	{
		Random random=new Random();
		String productId="P#"+Integer.toString(random.nextInt(10000));
		product.setProdId(productId);
		entityManager.persist(product);
		return productId;
	}
	@Override
	public void addProductImage(String productId, Image image) {
//		Random random=new Random();
//		Product product=entityManager.find(Product.class, productId);
//		List<Product> productList=new ArrayList<Product>();
//		productList.add(product);
////		entityManager.persist(image);
//		entityManager.persist(product);
////		entityManager.merge(image);
		
	}

}
