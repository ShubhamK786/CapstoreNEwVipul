package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Product;
import com.cg.capstore.repo.ICapstoreAdminRepo;

@Transactional
@Service("service")
public class CapstoreAdminServiceImpl implements ICapstoreAdminService{
	@Autowired
	ICapstoreAdminRepo repo;
	@Override
	public String addProduct(Product product) {
		return repo.addProduct(product);
		
	}
	@Override
	public void addProductImage(String productId, Image image) {
		repo.addProductImage(productId, image);
		
	}
	
	
}
