package com.cg.capstore.service;

import com.cg.capstore.bean.Image;
import com.cg.capstore.bean.Product;

public interface ICapstoreAdminService {
	public String addProduct(Product product);
	public void addProductImage(String productId, Image image);
}
